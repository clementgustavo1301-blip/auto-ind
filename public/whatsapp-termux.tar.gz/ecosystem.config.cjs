module.exports = {
  apps: [
    {
      name: "whatsapp-engine",
      script: "./start-engine.sh",
      autorestart: true,
      restart_delay: 3000,
      max_restarts: 100,
      watch: false
    },
    {
      name: "whatsapp-tunnel",
      script: "./start-tunnel.sh",
      autorestart: true,
      restart_delay: 4000,
      max_restarts: 100,
      watch: false
    }
  ]
};
